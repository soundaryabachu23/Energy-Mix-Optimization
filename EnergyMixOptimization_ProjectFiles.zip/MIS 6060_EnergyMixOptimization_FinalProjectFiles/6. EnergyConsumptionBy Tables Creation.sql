USE [Project_EnergyMixOptimization]

CREATE TABLE [dbo].[EnergyConsumptionByCommercial](
	[Commercial_id] [int] IDENTITY(1,1) NOT NULL,
	[Category] [varchar](255) NULL,
	[Date] [date] NULL,
	[VariableName] [varchar](255) NULL,
	[Value] [decimal](18, 2) NULL,
	[ETL_Add_DateTime] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[Commercial_id] ASC
));

CREATE TABLE [dbo].[EnergyConsumptionByIndustrial](
	[Industrial_id] [int] IDENTITY(1,1) NOT NULL,
	[Category] [varchar](255) NULL,
	[Date] [date] NULL,
	[VariableName] [varchar](255) NULL,
	[Value] [decimal](18, 2) NULL,
	[ETL_Add_DateTime] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[Industrial_id] ASC
));

CREATE TABLE [dbo].[EnergyConsumptionByResidential](
	[Residential_id] [int] IDENTITY(1,1) NOT NULL,
	[Category] [varchar](255) NULL,
	[Date] [date] NULL,
	[VariableName] [varchar](255) NULL,
	[Value] [decimal](18, 2) NULL,
	[ETL_Add_DateTime] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[Residential_id] ASC
));

ALTER TABLE [dbo].[EnergyConsumptionByCommercial] ADD  DEFAULT (getdate()) FOR [ETL_Add_DateTime];
ALTER TABLE [dbo].[EnergyConsumptionByIndustrial] ADD  DEFAULT (getdate()) FOR [ETL_Add_DateTime];
ALTER TABLE [dbo].[EnergyConsumptionByResidential] ADD  DEFAULT (getdate()) FOR [ETL_Add_DateTime];