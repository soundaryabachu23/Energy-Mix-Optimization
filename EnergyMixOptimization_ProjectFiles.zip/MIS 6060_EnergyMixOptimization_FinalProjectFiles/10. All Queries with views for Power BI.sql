-------------------Queries for Insights-----------------

--Create view [Total Commercial Energy Consumption by Year] as
SELECT  Category,Year(Date) as Year, SUM(Value) AS TotalCommercialEnergyConsumption
FROM     dbo.EnergyConsumptionByCommercial
WHERE  (Date BETWEEN '2012-01-01' AND '2023-10-01')
GROUP BY Category, year(date)


--Create view [Total Industrial Energy Consumption by Year] as
SELECT  Category,Year(Date) as Year, SUM(Value) AS TotalIndustrialEnergyConsumption
FROM     dbo.EnergyConsumptionByIndustrial
WHERE  (Date BETWEEN '2012-01-01' AND '2023-10-01')
GROUP BY Category, year(date)
order by Category

--Create view  [Total Residential Energy Consumption by Year] as
SELECT  Category,Year(Date) as Year, SUM(Value) AS TotalResidentialEnergyConsumption
FROM     dbo.EnergyConsumptionByResidential
WHERE  (Date BETWEEN '2012-01-01' AND '2023-10-01')
GROUP BY Category, year(date)
order by Category

--Create view [Total Energy Consumptionby Year, Sector, and Category] as
SELECT  Category, Year(Date) as Year, Sector, SUM(Value) AS TotalEnergyConsumption
from
(select *, 'Commercial' as Sector from EnergyConsumptionByCommercial union
select *, 'Residential' as Sector from EnergyConsumptionByResidential union
select *, 'Industrial' as Sector from EnergyConsumptionByIndustrial) as [All Sectors]
WHERE  (Date BETWEEN '2012-01-01' AND '2023-10-01')
GROUP BY Category,  year(date), Sector
order by Category, year(date), Sector;

-- create view [Total Energy Consumption by Category] as
SELECT  Category, SUM(Value) AS TotalEnergyConsumption
from
(select * from EnergyConsumptionByCommercial union
select * from EnergyConsumptionByResidential union
select * from EnergyConsumptionByIndustrial) as [All Sectors]
GROUP BY Category
order by Category;


-- Create view [% of Sector over all Sectors category] as
Select A.Category, A.Sector,round(((cast(A.TotalEnergyConsumption as float)/B.TotalEnergyConsumption)*100),2) as [% Sector Over Category]
from
(SELECT  Category,Sector, SUM(Value) AS TotalEnergyConsumption
from
(select *, 'Commercial' as Sector from EnergyConsumptionByCommercial union
select *, 'Residential' as Sector from EnergyConsumptionByResidential union
select *, 'Industrial' as Sector from EnergyConsumptionByIndustrial) as [All Sectors]
group by Category, Sector) as A
INNER JOIN
(SELECT  Category, SUM(Value) AS TotalEnergyConsumption
from
(select *, 'Commercial' as Sector from EnergyConsumptionByCommercial union
select *, 'Residential' as Sector from EnergyConsumptionByResidential union
select *, 'Industrial' as Sector from EnergyConsumptionByIndustrial) as [All Sectors]
group by Category ) B on A.Category = B.Category
order by A.Category, A.Sector;

-- %Consumption of every Variable over TotalComsumption in Industrial
Declare @ValueIndustrial Float;
SELECT @ValueIndustrial= SUM(Value) FROM [dbo].[EnergyConsumptionByIndustrial] 
WHERE VariableName IN ('TotalPrimaryEnergyIndustrial')

SELECT VariableName,SUM((Value/@ValueIndustrial)*100) AS [%ConsumptionIndustrial]
FROM [dbo].[EnergyConsumptionByIndustrial] 
WHERE VariableName NOT IN ('TotalPrimaryEnergyIndustrial')
GROUP BY VariableName
ORDER BY 2 DESC

-- CREATE VIEW [dbo].[%Consumption_of_every_Variable_over_TotalConsumption_in_Industrial]
AS
SELECT ec.VariableName,
       SUM((ec.Value / t.TotalPrimaryEnergyIndustrial) * 100) AS [%ConsumptionIndustrial]
FROM [dbo].[EnergyConsumptionByIndustrial] ec
INNER JOIN (
    SELECT SUM(Value) AS TotalPrimaryEnergyIndustrial
    FROM [dbo].[EnergyConsumptionByIndustrial]
    WHERE VariableName = 'TotalPrimaryEnergyIndustrial'
) t ON 1=1
WHERE ec.VariableName <> 'TotalPrimaryEnergyIndustrial'
GROUP BY ec.VariableName
ORDER BY [%ConsumptionIndustrial] DESC;



 -- %Consumption of every Variable over TotalComsumption in Commercial
--Top most is DistillateFuelOilCommercial
Declare @ValueCommercial Float;
SELECT @ValueCommercial= SUM(Value) FROM [dbo].[EnergyConsumptionByCommercial] 
WHERE VariableName IN ('TotalPrimaryEnergyCommercial')

SELECT VariableName,SUM((Value/@ValueCommercial)*100) AS [%ConsumptionCommercial]
FROM [dbo].[EnergyConsumptionByCommercial] 
WHERE VariableName NOT IN ('TotalPrimaryEnergyCommercial')
GROUP BY VariableName
ORDER BY 2 DESC

-- CREATE VIEW [dbo].[%Consumption_of_every_Variable_over_TotalConsumption_in_Commercial]
AS
SELECT ec.VariableName,
       SUM((ec.Value / t.TotalPrimaryEnergyCommercial) * 100) AS [%ConsumptionCommercial]
FROM [dbo].[EnergyConsumptionByCommercial] ec
INNER JOIN (
    SELECT SUM(Value) AS TotalPrimaryEnergyCommercial
    FROM [dbo].[EnergyConsumptionByCommercial]
    WHERE VariableName = 'TotalPrimaryEnergyCommercial'
) t ON 1=1
WHERE ec.VariableName <> 'TotalPrimaryEnergyCommercial'
GROUP BY ec.VariableName
ORDER BY [%ConsumptionCommercial] DESC;



--%Consumption of every Variable over TotalComsumption in Residential
Declare @ValueResidential Float;
SELECT @ValueResidential = SUM(Value) FROM [dbo].[EnergyConsumptionByResidential] 
WHERE VariableName IN ('TotalPrimaryEnergyResidential')

SELECT VariableName,SUM((Value/@ValueResidential)*100) AS [%ConsumptionResidential]
FROM [dbo].[EnergyConsumptionByResidential] 
WHERE VariableName NOT IN ('TotalPrimaryEnergyResidential')
GROUP BY VariableName
ORDER BY 2 DESC


-- CREATE VIEW [dbo].[%Consumption_of_every_Variable_over_TotalConsumption_in_Residential]
AS
SELECT ec.VariableName,
       SUM((ec.Value / t.TotalPrimaryEnergyResidential) * 100) AS [%ConsumptionResidential]
FROM [dbo].[EnergyConsumptionByResidential] ec
INNER JOIN (
    SELECT SUM(Value) AS TotalPrimaryEnergyResidential
    FROM [dbo].[EnergyConsumptionByResidential]
    WHERE VariableName = 'TotalPrimaryEnergyResidential'
) t ON 1=1
WHERE ec.VariableName <> 'TotalPrimaryEnergyResidential'
GROUP BY ec.VariableName
ORDER BY [%ConsumptionResidential] DESC;


--%Consumption of every Variable over TotalComsumption in Industrial,Years
--We will show that the BiomassIndustrial consumption% is reducing with time which is on the 
--In total consumption for industrial sector Biomass is the top competitor. 
--So, Analysing by its yearly trend for the industrial sector and also comparing with one non-renewable source(coal).
--we can shown trend in graph form.



 [SELECT VariableName,VarVal.Year,(Consumption/TotalConsumption)*100 AS [%Consumption]
,ROW_NUMBER() OVER(partition by VarVal.Year ORDER BY (Consumption/TotalConsumption)*100  DESC) AS RwN
FROM 
(
SELECT VariableName,Year(Date) Year,SUM(Value) AS Consumption
FROM [dbo].[EnergyConsumptionByIndustrial] 
WHERE VariableName NOT IN ('TotalPrimaryEnergyIndustrial')
GROUP BY VariableName,Year(Date))VarVal
INNER JOIN 
(SELECT Year(Date) AS Year,SUM(Value) TotalConsumption FROM [dbo].[EnergyConsumptionByIndustrial] 
WHERE VariableName IN ('TotalPrimaryEnergyIndustrial')
GROUP BY Year(Date)) TotVal
ON VarVal.Year =TotVal.Year
WHERE VarVal.VariableName ='CoalIndustrial'
ORDER BY VariableName,VarVal.Year,RwN
ORDER BY Year DESC,[%Consumption] DESC

-- CREATE VIEW [dbo].[IndustrialVariableConsumptionPercentage]
AS
SELECT
    VarVal.VariableName,
    VarVal.Year,
    (VarVal.Consumption / TotVal.TotalConsumption) * 100 AS [%Consumption],
    ROW_NUMBER() OVER(PARTITION BY VarVal.Year ORDER BY (VarVal.Consumption / TotVal.TotalConsumption) DESC) AS RwN
FROM 
(
    SELECT
        VariableName,
        YEAR(Date) AS Year,
        SUM(Value) AS Consumption
    FROM [dbo].[EnergyConsumptionByIndustrial] 
    WHERE VariableName NOT IN ('TotalPrimaryEnergyIndustrial')
    GROUP BY VariableName, YEAR(Date)
) AS VarVal
INNER JOIN 
(
    SELECT
        YEAR(Date) AS Year,
        SUM(Value) AS TotalConsumption
    FROM [dbo].[EnergyConsumptionByIndustrial] 
    WHERE VariableName IN ('TotalPrimaryEnergyIndustrial')
    GROUP BY YEAR(Date)
) AS TotVal ON VarVal.Year = TotVal.Year
ORDER BY VarVal.Year DESC, [%Consumption] DESC;



--%Consumption of every Variable over TotalComsumption in Commercial,Years
--We will show that the DistillateFuelOilCommercial consumption% is trend details.
--In total consumption for Commercial sector DistillateFuelOilCommercial is the top competitor. 

--try to find article on DistillateFuelOil Cost and Biomass Cost of usage.

SELECT VariableName,VarVal.Year,(Consumption/TotalConsumption)*100 AS [%Consumption]
--,ROW_NUMBER() OVER(partition by VarVal.Year ORDER BY (Consumption/TotalConsumption)*100  DESC) AS RwN
FROM 
(
SELECT VariableName,Year(Date) Year,SUM(Value) AS Consumption
FROM [dbo].[EnergyConsumptionByCommercial] 
WHERE VariableName NOT IN ('TotalPrimaryEnergyCommercial')
GROUP BY VariableName,Year(Date))VarVal
INNER JOIN 
(SELECT Year(Date) AS Year,SUM(Value) TotalConsumption FROM [dbo].[EnergyConsumptionByCommercial] 
WHERE VariableName IN ('TotalPrimaryEnergyCommercial')
GROUP BY Year(Date)) TotVal
ON VarVal.Year =TotVal.Year
WHERE VarVal.VariableName ='DistillateFuelOilCommercial'
--ORDER BY VariableName,VarVal.Year,RwN
ORDER BY Year DESC,[%Consumption] DESC

-- CREATE VIEW [dbo].[CommercialVariableConsumptionPercentage]
AS
SELECT
    VarVal.VariableName,
    VarVal.Year,
    (VarVal.Consumption / TotVal.TotalConsumption) * 100 AS [%Consumption]
FROM 
(
    SELECT
        VariableName,
        YEAR(Date) AS Year,
        SUM(Value) AS Consumption
    FROM [dbo].[EnergyConsumptionByCommercial] 
    WHERE VariableName NOT IN ('TotalPrimaryEnergyCommercial')
    GROUP BY VariableName, YEAR(Date)
) AS VarVal
INNER JOIN 
(
    SELECT
        YEAR(Date) AS Year,
        SUM(Value) AS TotalConsumption
    FROM [dbo].[EnergyConsumptionByCommercial] 
    WHERE VariableName = 'TotalPrimaryEnergyCommercial'
    GROUP BY YEAR(Date)
) AS TotVal ON VarVal.Year = TotVal.Year
ORDER BY VarVal.Year DESC, [%Consumption] DESC;



--%Consumption of every Variable over TotalComsumption in Residential,Years
--We will show that the DistillateFuelOilResidentialconsumption% is trend details.
--In total consumption for Residential sector  DistillateFuelOilResidential is the top competitor. 

SELECT VariableName,VarVal.Year,(Consumption/TotalConsumption)*100 AS [%Consumption]
--,ROW_NUMBER() OVER(partition by VarVal.Year ORDER BY (Consumption/TotalConsumption)*100  DESC) AS RwN
FROM 
(
SELECT VariableName,Year(Date) Year,SUM(Value) AS Consumption
FROM [dbo].[EnergyConsumptionByResidential] 
WHERE VariableName NOT IN ('TotalPrimaryEnergyResidential')
GROUP BY VariableName,Year(Date))VarVal
INNER JOIN 
(SELECT Year(Date) AS Year,SUM(Value) TotalConsumption FROM [dbo].[EnergyConsumptionByResidential] 
WHERE VariableName IN ('TotalPrimaryEnergyResidential')
GROUP BY Year(Date)) TotVal
ON VarVal.Year =TotVal.Year
WHERE VarVal.VariableName ='WoodResidential'
--ORDER BY VariableName,VarVal.Year,RwN
ORDER BY Year DESC,[%Consumption] DESC


-- CREATE VIEW [dbo].[ResidentialVariableConsumptionPercentage]
AS
SELECT
    VarVal.VariableName,
    VarVal.Year,
    (VarVal.Consumption / TotVal.TotalConsumption) * 100 AS [%Consumption]
FROM 
(
    SELECT
        VariableName,
        YEAR(Date) AS Year,
        SUM(Value) AS Consumption
    FROM [dbo].[EnergyConsumptionByResidential] 
    WHERE VariableName NOT IN ('TotalPrimaryEnergyResidential')
    GROUP BY VariableName, YEAR(Date)
) AS VarVal
INNER JOIN 
(
    SELECT
        YEAR(Date) AS Year,
        SUM(Value) AS TotalConsumption
    FROM [dbo].[EnergyConsumptionByResidential] 
    WHERE VariableName = 'TotalPrimaryEnergyResidential'
    GROUP BY YEAR(Date)
) AS TotVal ON VarVal.Year = TotVal.Year
ORDER BY VarVal.Year DESC, [%Consumption] DESC;


-- create view [% of Renewable and Non-Renewable consumtion to All Consumption] as
SELECT 
    100 *( SUM(CASE WHEN category = 'Non-Renewable' THEN TotalEnergyConsumption ELSE 0 END) / 
    SUM(CASE WHEN category = 'ALL' THEN TotalEnergyConsumption ELSE 1 END)) AS [Non-Renewable%],
    
    100 * SUM(CASE WHEN category = 'Renewable' THEN TotalEnergyConsumption ELSE 0 END) / 
    SUM(CASE WHEN category = 'ALL' THEN TotalEnergyConsumption ELSE 1 END) AS [Renewable%]
FROM 
(SELECT  Category, SUM(Value) AS TotalEnergyConsumption
from
(select * from EnergyConsumptionByCommercial union
select * from EnergyConsumptionByResidential union
select * from EnergyConsumptionByIndustrial) as [All Sectors]
GROUP BY Category) Cal; 

-- % of Renewable and Non-Renewable consumtion to All Consumption in Commercial
Declare @ValueCommercialAll Float;
SELECT @ValueCommercialAll= SUM(Value) FROM [dbo].[EnergyConsumptionByCommercial] 
WHERE Category IN ('ALL')

SELECT Category,SUM((Value/@ValueCommercialAll)*100) AS [%ConsumptionCommercial]
FROM [dbo].[EnergyConsumptionByCommercial] 
WHERE Category NOT IN ('ALL')
GROUP BY Category
ORDER BY 2 DESC

-- CREATE VIEW [dbo].[%_of_Renewable_and_NonRenewable_consumption_to_All_Consumption_in_Commercial]
AS
SELECT ec.Category,
       SUM((ec.Value / t.TotalCommercialAll) * 100) AS [%ConsumptionCommercial]
FROM [dbo].[EnergyConsumptionByCommercial] ec
INNER JOIN (
    SELECT SUM(Value) AS TotalCommercialAll
    FROM [dbo].[EnergyConsumptionByCommercial]
    WHERE Category = 'ALL'
) t ON 1=1
WHERE ec.Category <> 'ALL'
GROUP BY ec.Category
ORDER BY [%ConsumptionCommercial] DESC;



--% of Renewable and Non-Renewable consumtion to All Consumption in Industrial
Declare @ValueIndustrialAll Float;
SELECT @ValueIndustrialAll= SUM(Value) FROM [dbo].[EnergyConsumptionByIndustrial] 
WHERE Category IN ('ALL')

SELECT Category,SUM((Value/@ValueIndustrialAll)*100) AS [%ConsumptionIndustrial]
FROM [dbo].[EnergyConsumptionByIndustrial] 
WHERE Category NOT IN ('ALL')
GROUP BY Category
ORDER BY 2 DESC

-- CREATE VIEW [dbo].[%_of_Renewable_and_NonRenewable_consumption_to_All_Consumption_in_Industrial]
AS
SELECT ec.Category,
       SUM((ec.Value / t.TotalIndustrialAll) * 100) AS [%ConsumptionIndustrial]
FROM [dbo].[EnergyConsumptionByIndustrial] ec
INNER JOIN (
    SELECT SUM(Value) AS TotalIndustrialAll
    FROM [dbo].[EnergyConsumptionByIndustrial]
    WHERE Category = 'ALL'
) t ON 1=1
WHERE ec.Category <> 'ALL'
GROUP BY ec.Category
ORDER BY [%ConsumptionIndustrial] DESC;


--% of Renewable and Non-Renewable consumtion to All Consumption in Residential
Declare @ValueResidentialAll Float;
SELECT @ValueResidentialAll= SUM(Value) FROM [dbo].[EnergyConsumptionByResidential] 
WHERE Category IN ('ALL')

SELECT Category,SUM((Value/@ValueResidentialAll)*100) AS [%ConsumptionResidential]
FROM [dbo].[EnergyConsumptionByResidential] 
WHERE Category NOT IN ('ALL')
GROUP BY Category
ORDER BY 2 DESC

-- CREATE VIEW [dbo].[%_of_Renewable_and_NonRenewable_consumption_to_All_Consumption_in_Residential]
AS
SELECT ec.Category,
       SUM((ec.Value / t.TotalResidentialAll) * 100) AS [%ConsumptionResidential]
FROM [dbo].[EnergyConsumptionByResidential] ec
INNER JOIN (
    SELECT SUM(Value) AS TotalResidentialAll
    FROM [dbo].[EnergyConsumptionByResidential]
    WHERE Category = 'ALL'
) t ON 1=1
WHERE ec.Category <> 'ALL'
GROUP BY ec.Category
ORDER BY [%ConsumptionResidential] DESC;



-------------SSIS Changes---------------
--SSIS
--Data types
--1 lookup for FK retriaval
--before data insertion we checked with lookup



-------------------Others----------------------------------
SELECT DISTINCT Category,VariableName FROM [dbo].[EnergyConsumptionByCommercial]
UNION ALL
SELECT DISTINCT Category,VariableName FROM [dbo].[EnergyConsumptionByResidential] 
UNION ALL
SELECT DISTINCT Category,VariableName FROM [dbo].[EnergyConsumptionByIndustrial] 

SELECT * from [dbo].[EnergyConsumptionByIndustrial] 


SELECT VariableName,SUM(Value) AS TotalValue FROM [dbo].[EnergyConsumptionByIndustrial] 
WHERE VariableName IN ('TotalPrimaryEnergyIndustrial','CoalIndustrial')
GROUP BY VariableName

SELECT * FROM [dbo].[EnergyConsumptionByCommercial]













