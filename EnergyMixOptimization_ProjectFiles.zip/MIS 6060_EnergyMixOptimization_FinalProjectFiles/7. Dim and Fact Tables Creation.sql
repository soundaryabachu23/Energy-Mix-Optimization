CREATE TABLE [dbo].[DimCategory](
	[CategoryID] [int] IDENTITY(1,1) NOT NULL,
	[CategoryName] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[CategoryID] ASC
));

CREATE TABLE [dbo].[DimVariable](
	[VariableID] [int] IDENTITY(1,1) NOT NULL,
	[CategoryID] [int] NULL,
	[VariableName] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[VariableID] ASC
));

CREATE TABLE [dbo].[DimDate](
	[DateID] [int] IDENTITY(1,1) NOT NULL,
	[Date] [date] NULL,
	[WeekDay] int NULL,
	[WeekDayName] [varchar](255) NULL,
	[Month] int NULL,
	[MonthName] [varchar](255) NULL,
	[Year] int NULL,
PRIMARY KEY CLUSTERED 
(
	[DateID] ASC
));

CREATE TABLE [dbo].[FactCommercial](
	[CommercialID] [int] IDENTITY(1,1) NOT NULL,
	[VariableID] [int] NULL,
	[DateID] [int] NULL,
	[Value] [decimal](18, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[CommercialID] ASC
));

CREATE TABLE [dbo].[FactIndustrial](
	[IndustrialID] [int] IDENTITY(1,1) NOT NULL,
	[VariableID] [int] NULL,
	[DateID] [int] NULL,
	[Value] [decimal](18, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[IndustrialID] ASC
));

CREATE TABLE [dbo].[FactResidential](
	[ResidentialID] [int] IDENTITY(1,1) NOT NULL,
	[VariableID] [int] NULL,
	[DateID] [int] NULL,
	[Value] [decimal](18, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[ResidentialID] ASC
));


ALTER TABLE [dbo].[DimVariable]  WITH CHECK ADD FOREIGN KEY([CategoryID]) REFERENCES [dbo].[DimCategory] ([CategoryID])

ALTER TABLE [dbo].[FactCommercial]  WITH CHECK ADD FOREIGN KEY([VariableID]) REFERENCES [dbo].[DimVariable] ([VariableID])
ALTER TABLE [dbo].[FactIndustrial]  WITH CHECK ADD FOREIGN KEY([VariableID]) REFERENCES [dbo].[DimVariable] ([VariableID])
ALTER TABLE [dbo].[FactResidential]  WITH CHECK ADD FOREIGN KEY([VariableID]) REFERENCES [dbo].[DimVariable] ([VariableID])

ALTER TABLE [dbo].[FactCommercial]  WITH CHECK ADD FOREIGN KEY([DateID]) REFERENCES [dbo].[DimDate] ([DateID])
ALTER TABLE [dbo].[FactIndustrial]  WITH CHECK ADD FOREIGN KEY([DateID]) REFERENCES [dbo].[DimDate] ([DateID])
ALTER TABLE [dbo].[FactResidential]  WITH CHECK ADD FOREIGN KEY([DateID]) REFERENCES [dbo].[DimDate] ([DateID])