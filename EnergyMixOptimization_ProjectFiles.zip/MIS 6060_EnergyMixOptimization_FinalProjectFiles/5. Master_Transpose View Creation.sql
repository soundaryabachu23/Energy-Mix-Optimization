CREATE VIEW [dbo].[Master_Transpose] AS 
SELECT CAST(CONCAT([Year],'-',[Month],'-01') AS DATE) AS [Date],
CASE WHEN EnergySource LIKE '%Commercial' THEN 'Commercial'
WHEN EnergySource LIKE '%Industrial' THEN 'Industrial'
WHEN EnergySource LIKE '%Residential' THEN 'Residential' END AS Source,
EnergySource AS VariableName,
CASE WHEN 
EnergySource IN (
 'BiomassIndustrial'
,'BiomassCommercial'
,'SolarCommercial'
,'SolarIndustrial'
,'SolarResidential'
,'WoodResidential'
,'WoodIndustrial'
,'WoodCommercial'
,'WindCommercial'
,'WindIndustrial'
,'GeothermalCommercial'
,'GeothermalResidential'
,'GeothermalIndustrial'
,'WasteIndustrial'
,'WasteCommercial') THEN 'Renewable'
WHEN 
EnergySource IN (
 'CoalIndustrial'
,'DistillateFuelOilCommercial'
,'DistillateFuelOilIndustrial'
,'ResidualFuelOilCommercial'
,'ResidualFuelOilIndustrial'
,'DistillateFuelOilResidential'
) THEN 'Non-Renewable'
WHEN 
EnergySource IN (
 'TotalPrimaryEnergyCommercial'
,'TotalPrimaryEnergyIndustrial'
,'TotalPrimaryEnergyResidential'
) THEN 'ALL'
END AS Category,
CAST(EnergyValue AS Decimal(18,2)) AS Value
FROM (SELECT [Year], [Month], EnergySource, EnergyValue
FROM 
   (SELECT [Year], [Month],
          BiomassIndustrial
,BiomassCommercial
,CoalIndustrial
,WoodResidential
,DistillateFuelOilCommercial
,DistillateFuelOilIndustrial
,GeothermalIndustrial
,SolarCommercial
,SolarIndustrial
,SolarResidential
,WoodIndustrial
,WasteCommercial
,ResidualFuelOilCommercial
,ResidualFuelOilIndustrial
,DistillateFuelOilResidential
,TotalPrimaryEnergyCommercial
,GeothermalCommercial
,GeothermalResidential
,WasteIndustrial
,WindCommercial
,WindIndustrial
,TotalPrimaryEnergyIndustrial
,TotalPrimaryEnergyResidential
,WoodCommercial
    FROM [dbo].[EnergyMixOptimization_Master]) p
UNPIVOT
   (EnergyValue FOR EnergySource IN 
      (BiomassIndustrial
,BiomassCommercial
,CoalIndustrial
,WoodResidential
,DistillateFuelOilCommercial
,DistillateFuelOilIndustrial
,GeothermalIndustrial
,SolarCommercial
,SolarIndustrial
,SolarResidential
,WoodIndustrial
,WasteCommercial
,ResidualFuelOilCommercial
,ResidualFuelOilIndustrial
,DistillateFuelOilResidential
,TotalPrimaryEnergyCommercial
,GeothermalCommercial
,GeothermalResidential
,WasteIndustrial
,WindCommercial
,WindIndustrial
,TotalPrimaryEnergyIndustrial
,TotalPrimaryEnergyResidential
,WoodCommercial)
)AS unpvt)A

